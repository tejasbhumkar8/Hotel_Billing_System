/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotel.billing.mgmt;
/**
 *
 * @author MOHAN
 */
public class HotelBillingMgmt {
    
    public HotelBillingMgmt()
    {Login l=new Login();l.setVisible(true);
     
       // CreateBill b=new CreateBill();
       // b.setVisible(true);
       
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    HotelBillingMgmt m1=new HotelBillingMgmt();
   
    }
    
}
